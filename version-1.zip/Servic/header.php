<!-- <h1 style="text-align: center; margin-bottom: 20px;">Servic</h1> -->

<div style=" position: relative; text-align: center;font-size: 40px;">Servic</div>
<link rel="stylesheet" type="text/css" href="style.css">
<div class="navbar">
    <a href="index.php">Home</a>
    <a href="about.php">About</a>
    <a href="services.php">Services</a>
    <a href="news.php">News</a>
    <a href="contact.php">Contact</a>
    <a href="curl.php">Users</a>
</div>