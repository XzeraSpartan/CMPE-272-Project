<link rel="stylesheet" type="text/css" href="style.css">
<div class="footer">
    &copy; 2023 Servic. All rights reserved.
</div>