# CMPE-272-Project
 Marketplace with Entertainment, Services and Fashion. Allahu Akbar
